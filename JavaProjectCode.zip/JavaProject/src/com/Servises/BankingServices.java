package com.Servises;

import com.exceptions.InvalidAccountNoException;

//Menu card 
public interface BankingServices
{
	//abstraction method declaration
    int openAccount(int accNo,String type,float amount);
    float deposit(int accNo,float amount) throws InvalidAccountNoException;
    float balEnq(int accNo)throws InvalidAccountNoException;
    String getAccountDetail( );
    float withdraw(int accNo,float amount)throws InvalidAccountNoException;
}
