package com.Servises;

import com.exceptions.EnterStrongPassword;

//menu card interface
public interface UserServises 
{
	//abstraction method collection for user business class implementation
	String signUp(String userName,String password,String question,String answer) throws EnterStrongPassword;
    String SignUpConstraint(String UserNm,String Passw,String Que,String Ans);
	boolean signIn(String userName,String password);
	String forgotPass(String userName,String question ,String answer);
	String updatePassword(String userName, String password, String newPassword);

}
