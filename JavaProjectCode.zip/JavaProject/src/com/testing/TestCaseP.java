package com.testing;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.exceptions.InvalidAccountNoException;
import com.serviceimpl.AccountTransaction;

import junit.framework.TestCase;

//test class for apply test or check balance is not negative 
public class TestCaseP extends TestCase
{
	AccountTransaction at;
	//object create before test run
	@Before
	public void creatObject()
	{
		at=new AccountTransaction();   //create object
	}
    
	//method  which we want to test
	@Test
	public void testDeposit() throws InvalidAccountNoException
	{
		float bal=at.deposit(1, 15673.0f);
		assertTrue(bal>0);         //check balance is not negative
	}
	//2 method which we want to test
    @Test
	public void testBalEnq() throws InvalidAccountNoException
	{
    	float balEnq=at.balEnq(1);
    	assertTrue(balEnq>0); //check for a balance is not negative
		
	}
    
    //after test run destroy the object
   @After
    public void releaseObj()
    {
    	at=null;  //release object
    }
}
