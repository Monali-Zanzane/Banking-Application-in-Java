package com.daoInterfacendimpl;


import com.bin.User;

public interface DAOOpUser
{
	//abstract method declaration
		void insertAccount(User us);
		User retriveAccountData(String userName,String password);
		void UpdateAccount(String userName,String password);

}
