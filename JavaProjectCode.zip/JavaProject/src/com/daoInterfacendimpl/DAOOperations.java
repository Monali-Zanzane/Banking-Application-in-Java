package com.daoInterfacendimpl;

import com.bin.Account;

//CRUD operation interface
public interface DAOOperations
{
	//abstract method declaration
	void insertAccount(Account acc);
	Account retriveAccountData(int accNo);
	void UpdateAccount(int accNo,float amount);

}
