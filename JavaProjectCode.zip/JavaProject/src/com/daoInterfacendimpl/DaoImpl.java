package com.daoInterfacendimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.bin.Account;
import com.provider.DatabaseConnectionProvider;


//SQL operations / Data operation implementation class
//CRUD operation implementation
public class DaoImpl implements DAOOperations
{
	
	//create connection
	Connection con=DatabaseConnectionProvider.createConnection();
	
	//implementation of insert query of new database in table
	public void insertAccount(Account acc)
	{
		//code under try catch block to get handle very well
		try
		{
			
			 // to accept dynamic values user given value  prepared statement /insert query
		     PreparedStatement pst=con.prepareStatement("insert into Account_Table values(?,?,?)");
		     pst.setInt(1,acc.getaccNo());
		     pst.setString(2, acc.getaccType());
		     pst.setFloat(3,acc.getaccBal());
		     pst.executeUpdate();
		
		}
		
		//catch run when get any kind of exception
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
	}
    
	
	//implementation of select query to print data which is already in database
	public Account retriveAccountData(int accNo)
	{
		//Account class data carrier object
		Account acc=null;
		
		//try block
 
		try
		{
			
			//select query in prepare statement to accept dynamic values
			PreparedStatement pst=con.prepareStatement("select * from Account_Table where accNo=?");
			pst.setInt(1, accNo);
			ResultSet rs=pst.executeQuery();    //resultset store data
			
			// loop to get record how many user want that much 
			if(rs.next())
			{
				int accN=rs.getInt(1);
				String accType=rs.getString(2);
				float accBal=rs.getFloat(3);
				acc=new Account(accN,accType,accBal);
			}
			
			//else if record not found
			else
			{
				System.out.println("record not found");
				acc=null;
			}
			
		}
		
		// catch block when cougth any exception
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return acc;  //return account
	}
	
    
	//implementation of update query on database to update any values from database
	public void UpdateAccount(int accNo, float amount)
	{
		
		//try catch block
		try
		{
			 //update query 
		     PreparedStatement pst=con.prepareStatement("update Account_Table set  accbal=? where accNo=?");
		     pst.setFloat(1, amount);
		     pst.setInt(2, accNo);
		     pst.executeQuery();
		    // ResultSet rs=pst.executeQuery();      //resultset to store value
		}
		
		//catch block to handle exception
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
}