package com.daoInterfacendimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.bin.User;
import com.provider.DatabaseConnectionUserLogin;

public class DAOOpUserImpl implements DAOOpUser
{

	//create connection
	Connection con=DatabaseConnectionUserLogin.createConnection();
	
	//implementation of insert query of new database in table
	public void insertAccount(User us)
	{
		//code under try catch block to get handle very well
		try
		{
			
			 // to accept dynamic values user given value  prepared statement /insert query
		     PreparedStatement pst=con.prepareStatement("insert into Login_Table values(?,?,?,?)");
		     pst.setString(1, us.getUserName());
		     pst.setString(2, us.getPassword());
		     pst.setString(3, us.getQuestion());
		     pst.setString(4, us.getAnswer());
		     pst.executeUpdate();
		
		}
		
		//catch run when get any kind of exception
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		
	}
    
	
	//implementation of select query to print data which is already in database
	public User retriveAccountData(String userName,String password)
	{
		//User class data carrier object
		User us=null;
		
		//try block
 
		try
		{
			
			//select query in prepare statement to accept dynamic values
			PreparedStatement pst=con.prepareStatement("select * from Login_Table where userName=? and passwords=?");
			pst.setString(1, userName);
			pst.setString(2, password);
			ResultSet rs=pst.executeQuery();    //resultset store data
			
			// loop to get record how many user want that much 
			if(rs.next())
			{
				String userNam=rs.getString(1);
				String pass=rs.getString(2);
				String question=rs.getString(3);
				String answer=rs.getString(4);
				
				us=new User(userNam,pass,question,answer);
			}
			
			//else if record not found
			else
			{
				System.out.println("record not found");
				us=null;
			}
			
		}
		
		// catch block when get any exception
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return us;  //return User
	}
	
    
	//implementation of update query on database to update any values from database
	public void UpdateAccount(String userName, String password)
	{
		
		//try catch block
		try
		{
			 //update query 
		     PreparedStatement pst=con.prepareStatement("update Logic_Table set userName=? passwords=? where userName=?");
		   
		     pst.setString(1, userName);
		    pst.setString(2, password);
		     pst.executeQuery();
		    // ResultSet rs=pst.executeQuery();      //resultset to store value
		}
		
		//catch block to handle exception
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
