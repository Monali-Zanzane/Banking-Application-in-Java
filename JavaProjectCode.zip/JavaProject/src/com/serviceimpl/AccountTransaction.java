package com.serviceimpl;

import com.Servises.BankingServices;
import com.bin.Account;
import com.daoInterfacendimpl.DAOOperations;
import com.daoInterfacendimpl.DaoImpl;
import com.exceptions.InvalidAccountNoException;

//business logic class
public class AccountTransaction implements BankingServices
{
	
	//has a account 
	private Account acc;
	//dao class object
	DAOOperations dao=new DaoImpl();
	//Biasness logic
	//account creation or opening
	public int openAccount(int accNo,String type ,float amount)
	{
		acc=new Account(accNo,type,amount);
		//insert data into database,
		dao.insertAccount(acc);
		System.out.println("Account open successfully");
		return acc.getaccNo();
		
	}
	
	//print  account detail
	public String getAccountDetail( )
	{
		return acc.getaccNo()+"/"+"acc bal"+"/"+acc.getaccBal()+"/"+"acc type"+"/"+acc.getaccType()+"/"+"ifsc code"+acc.getifscCode();
				
	}
	
	//to deposit money in our account
	public float deposit(int accNo,float amount)throws InvalidAccountNoException
	{
		//get account number through user by sql query
		Account acc=dao.retriveAccountData(accNo);
		
		if(acc==null)
		{
			//if account is null throw exception
			throw new InvalidAccountNoException("account no is incorrect");
		}
		
		else
		{
			//add amount
			acc.setAccBal(acc.getaccBal()+amount);
			//update balance in db
			dao.UpdateAccount(accNo,acc.getaccBal());
		}
		
		
		/*
		 * if(acc.getaccNo()==accNo) { acc.setAccBal(acc.getaccBal()+amount); } else {
		 * throw new InvalidAccountNoException("account no is incorrect");
		 * 
		 * }
		 */
		return acc.getaccBal();
	}
	
	//method to do inquiry  of the balance
	public float balEnq(int accNo)throws InvalidAccountNoException
	{
		//extract data from database
		Account acc=dao.retriveAccountData(accNo);

		float bal=0.0f;
		if(acc==null)
		{
			//through exception if account is null
			throw new InvalidAccountNoException("account no is incorrect");
		}
		else
		{
			//get account balance
			bal=acc.getaccBal();

		}
		return bal;
	}
	
	
	//Withdraw method to withdraw some money from account
	public  float withdraw(int accNo,float amount) throws InvalidAccountNoException
	{
		
		//extract data from database
		Account acc=dao.retriveAccountData(accNo);
		
		if(acc==null)
		{
			//throw exception if account is null
			throw new InvalidAccountNoException("account no is incorrect");
		}
		else
		{
			// minus withdraw amount 
			acc.setAccBal(acc.getaccBal()-amount);
			//update balance in database
			dao.UpdateAccount(accNo,acc.getaccBal());
		}
		
		return acc.getaccBal();   //return updated balance
		
		
	}

}


