package com.serviceimpl;

import com.Servises.UserServises;
import com.bin.User;
import com.daoInterfacendimpl.DAOOpUser;
import com.daoInterfacendimpl.DAOOpUserImpl;
import com.exceptions.EnterStrongPassword;


//business logic
public class UserServicesImpl implements  UserServises 
{
	//has a user
	private User ur;
	
	//DAO object
	DAOOpUser daou=  new DAOOpUserImpl();
	
	//method to signup / create account
	public String signUp(String userName,String password,String question,String answer) throws EnterStrongPassword
	{
		//String login=yes;
		ur=new User(userName,password,question,answer);
		try
		{
			//logic for strong password
			if(password.endsWith("$123"))
			{
				password=ur.getPassword();
			  
			}
			else
			{
				//throw error if password is not strong
				throw new EnterStrongPassword("enter strong password which is end with $123");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Welcome "+"/"+userName+"/"+"your account succesfully open with user name :-");
		return userName;
	}
	
	//method to accept strong password
	public String SignUpConstraint(String UserNm,String Passw,String Que,String Ans)
	{
		String ss="";
		
		int ll;
		 ll=Passw.length();
		if(UserNm==""||Passw==""||Que==""||Ans=="")
		{
		 ss=" Please Check  Something is missing";
		 return ss;
		}
		 if(ll>=8)
		 {
			 ss="No Issue";
			return ss;
			 
		 }
		else
		{
			ss="Check password";
			return ss;
		
		}
		
		 
		
	}
	
	
	//method to signin / login in our account
	public boolean signIn(String userName,String password)
	{
		//extract data from database
		User us=daou.retriveAccountData(userName,password);
		
		if(us==null)
		{
			//if record not found in table
			
			System.out.println("please enter correct username or password");
				return false;
			
		}
		else
		{
          //else print welcome massage
			System.out.println(" Welcome!!!!!!!!"+userName);
			return true;
			
		}
		
		
		/*
		 * //check password is match or not
		 *  if(ur.getUserName().equals(userName) &&
		 * ur.getPassword().equals(password)) 
		 * {
		 * System.out.println(" Welcome!!!!!!!!"+userName); return true; 
		 * }
		 *  else
		 *   {
		 *    //else
		 * give massage System.out.println("please enter correct username or password");
		 * return false; 
		 * }
		 */
	}
	
    //method when password forget and get otp
	public String forgotPass(String userName,String question ,String answer)
	{
		String cod="False";
		
		//equals method to compare contains
		if(ur.getUserName().equals(userName) && ur.getQuestion().equals(question) && ur.getAnswer().equals(answer))
		{
		  cod="ssss";
		  //get otp
		  System.out.println("you are otp to passwor change"+cod);  
		}
		else
		{
			
			//give massage
			System.out.println("please fill correct info"+userName);
		}
		return cod;    //return otp
	}
	
	
	//method to update new password
	public String updatePassword(String userName, String password, String newPassword)
	{
		// Equal method to compare contains
		if(ur.getUserName().equals(userName))
		{
			//set new password
			ur.setPassword(newPassword);
			System.out.println("Update password successfully.......:)");
		}
		else
		{
			//else give massage
			System.out.println("unable to update.....:("+userName);
		}
		return newPassword;
	}
}
