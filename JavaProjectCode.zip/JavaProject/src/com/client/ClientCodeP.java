package com.client;

import java.util.Scanner;

import com.Servises.BankingServices;
import com.Servises.UserServises;
import com.exceptions.EnterStrongPassword;
import com.exceptions.InvalidAccountNoException;
import com.provider.BusinessObjectPrivider;
import com.provider.UserObjectiveProvider;
import com.serviceimpl.UserServicesImpl;

//main class
public class ClientCodeP 
{

			public static void main(String[] args) {
               //object creation for account 
				BankingServices bank=BusinessObjectPrivider.createObject();
				/*	
				int accNo=bank.openAccount("Savings",0.0f);
				System.out.println("Account opened with accNo ....."+accNo);

				try
			{
				float updateBal=bank.deposite(accNo,20000.0f);
				System.out.println("Update Bal is ....."+updateBal);


			}

				catch(AccountException e)
				{
					e.printStackTrace();
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}

				try
			{

					float bal=bank.balEnq(100);
					System.out.println("Current Bal is ....."+bal);


			}
				catch(AccountException e)
				{
					e.printStackTrace();
				}

				catch(Exception e)
				{
					e.printStackTrace();
				}

				try
			{	
				float bal1=bank.withdrawl(accNo,3000);
				System.out.println("After withdrawl Bal is ....."+bal1);

				}

				catch(AccountException e)
				{
					e.printStackTrace();
				}

				catch(Exception e)
				{
					e.printStackTrace();
				}


				bank.PrnitAccDtails();
				 */


				//UserServices US= UserObjectiveProvider.createObject();
				
				
				//object creation for user login
				  UserServises US=UserObjectiveProvider.createObject();


				int ch1;
				do
				{		
                    //scanner to take input from keyboard
					Scanner sc=new Scanner(System.in);
					//ask choice for operation
					System.out.println("*Enter choice *  1.SignUp  //   2.SignIn   //   3.ForgetPassword   //  4.UpdatePasswor");
					ch1=sc.nextInt();

                    //swich cases for choice implementation
					switch(ch1)
					{
                      //sign up 
					case  1:
						System.out.println("Enter User Name:");
						String unm=sc.next();          //take user name
						System.out.println("Enter Password:");
						String pass=sc.next();             //take password
						System.out.println("Enter Quetion ::");
						String que=sc.next();             //take question 
						System.out.println("Enter Answer:");
						String ans=sc.next();             //take answer
						try
						{
							//sign up method call
						String A1=US.signUp(unm,pass,que,ans);
						System.out.println(A1);
						}
						catch(EnterStrongPassword e)
						{
							e.printStackTrace();
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}

						break;
                        //sign in
					case 2:
                              
						System.out.println("Enter User Name:");
						unm=sc.next();
						System.out.println("Enter Password:");
						pass=sc.next();
						boolean A2=US.signIn(unm,pass);
						System.out.println(A2);
						if(A2==true)
						{
							int ch;
							do
							{		
                                 //scanner 2 object
								Scanner sc1=new Scanner(System.in);
								//choices for account operation
								System.out.println("*Enter choice *  1.Open Account  //  2.Deposite Money   //  3.Balnace Enquiry   //  4.Withdraw Money // 5.Account details");
								ch=sc1.nextInt();


								switch(ch)
								{
                                        //open account
								case  1:
									System.out.println("enter acount number");
									int accNo=sc.nextInt();
									System.out.println("Enter Amount to be paid");
									float amt=sc1.nextInt();
									System.out.println("Enter Type of account to open:");
									String type=sc1.next();
									int accNo1=bank.openAccount(accNo,type,amt);      //method call for open account

									break;
                                         //deposit 
								case 2:
									System.out.println("Enter Account Number : ");
									int accno=sc1.nextInt();
									System.out.println("Enter Amount to be deposite :");
									amt=sc1.nextInt();

									try
									{
										float updateBal=bank.deposit(accno,amt);  //deposit method call
										System.out.println("Update Bal is ....."+updateBal);


									}

									catch(InvalidAccountNoException e)
									{
										e.printStackTrace();
									}
									catch(Exception e)
									{
										e.printStackTrace();
									}


									break;
                                   //balance inquiry
								case  3:
									System.out.println("Enter Account Number : ");
									accno=sc1.nextInt();
									try
									{

										float bal=bank.balEnq(accno); //method call
										System.out.println("Current Bal is ....."+bal);


									}
									catch(InvalidAccountNoException e)
									{
										e.printStackTrace();
									}

									catch(Exception e)
									{
										e.printStackTrace();
									}

									break;
                                   //withdrawal method
								case  4:
									System.out.println("Enter Account Number : ");
									accno=sc1.nextInt();
									System.out.println("Enter Amount to be withdraw : ");
									amt=sc.nextInt();
									try
									{	
										float bal1=bank.withdraw(accno,amt);           //method call
										System.out.println("After withdrawl Bal is ....."+bal1);

									}

									catch(InvalidAccountNoException e)
									{
										e.printStackTrace();
									}

									catch(Exception e)
									{
										e.printStackTrace();
									}

                                       //exit from case
									break;
                                       //print account detail
								case 5:
									String detail= bank.getAccountDetail();   //method call
									System.out.println(detail);
									break;

								default:
									System.out.println("*Invalid choice *");
									break;


								}

							}  while(ch!=6);                //if choice is greater than 6 then exit from switch case




						}

						break;
                    //forget password
					case  3:
						System.out.println("Enter User Name:");
						unm=sc.next();
						System.out.println("Enter Quetion ::");
						que=sc.next();
						System.out.println("Enter Answer:");
						ans=sc.next();
						String A3=US.forgotPass(unm,que,ans);          //method call
						System.out.println(A3);

						break;
						//update password method
					case  4:
						System.out.println("Enter User Name:");
						unm=sc.next();
						System.out.println("Enter Existing Password:");
						pass=sc.next();
						System.out.println("Enter New Password:");
						String npass=sc.next();
						String A4=US.updatePassword(unm,pass,npass);   //method call  
						System.out.println(A4);

						break;

					default:               //default when choice is incorrect
						System.out.println("*Invalid choice *");
						break;


					}

				}  while(ch1!=5);              //limitation up to run






			}

		}
		
//GOOGLE =GLOBAL ORGANIZATION OF ORIENTED GROUP LANGUAGE OF EARTH
//YEHOO = YET ENOTHER HERARCHICAL OFICIASE ORACLE	


