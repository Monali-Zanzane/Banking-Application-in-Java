package com.provider;

import java.io.FileInputStream;
import java.util.Properties;

import com.Servises.BankingServices;
import com.serviceimpl.AccountTransaction;

//used to make business logic class
public class BusinessObjectPrivider
{
  public static BankingServices createObject()
  {
	  //Banking services object creation
	  BankingServices obj=null;
	  //try catch block
	  try
	  {
		  
		  //file to decoupling
		  FileInputStream fis=new FileInputStream(".//Resources//config.properties");
		  Properties p=new Properties();      //properties object creation
		  p.load(fis);
		  String busClass=p.getProperty("BusinessClass");//load account transaction class path through this
		  
		  obj=(BankingServices) Class.forName(busClass).newInstance();  //down casting is done here 
		  
	  }
	  
	  //catch to handle exception
	  catch(Exception e)
	  {
		  e.addSuppressed(e);
	  }
	  return obj;
  }
}
