package com.provider;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

//used to make database connection
public class DatabaseConnectionProvider
{
	public static Connection createConnection()
	{
		//connection creation
	
	    Connection con=null;
	    
	    //try catch block
	   try
	   {
		   
		    FileInputStream fis=new FileInputStream(".//Resources//DBconfig.properties"); //decoupling
		    Properties p=new Properties();  //properties object
		    p.load(fis);
		    String driver=p.getProperty("driver");
		    String url=p.getProperty("url");
		    String user=p.getProperty("username");
		    String pass=p.getProperty("password");
		
		    Class.forName(driver); //path for Driver class
		
		    con=DriverManager.getConnection(url,user,pass); //Data base connection path url username password
		
	    }
	    catch(Exception e)
	    {
	    	
		    e.printStackTrace();
	    }
	
	    return con;

    }
}
