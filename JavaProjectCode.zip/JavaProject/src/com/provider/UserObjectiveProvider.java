package com.provider;


import com.Servises.UserServises;
//import com.serviceimpl.AccountTransaction;
import com.serviceimpl.UserServicesImpl;
//user object provider class
public class UserObjectiveProvider {

	public static UserServises createObject()
	  {
		  return new UserServicesImpl();
	  }

}







