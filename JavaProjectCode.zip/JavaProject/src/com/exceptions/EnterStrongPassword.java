package com.exceptions;

//user exception to get strong password
public class EnterStrongPassword extends Exception
{
	

	//data is not private because we want to access it in another class 
	String msg;
	public EnterStrongPassword (String msg)
	{
		this.msg=msg;
	}
	public String toString()
	{
		return "exception is:"+msg;
	}

}
