package com.exceptions;


//user define exception class get when account number is not correct 
public class InvalidAccountNoException extends Exception
{
	//data is not private because we want to access it in another class 
	String msg;
	public InvalidAccountNoException(String msg)
	{
		this.msg=msg;
	}
	public String toString()
	{
		return "exception is:"+msg;
	}

}
